<?php




// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

//Require Cardinity SDK
require_once plugin_dir_path(__FILE__) . "vendor/autoload.php";

//Define gateway name
define("CARDINITY_GATEWAY_NAME", "edd_cardinity_gateway");

$is_external_enabled = false;
if(get_option('edd_settings')['edd_cardinity_gateway_external_enable'] == 'on' || get_option('edd_settings')['edd_cardinity_gateway_external_enable'] == 1){
    $is_external_enabled = true;
}

/**
 * Encode data to Base64URL
 * @param string $data
 * @return boolean|string
 */
function encodeBase64Url($data)
{
    $b64 = base64_encode($data);

    if ($b64 === false) {
        return false;
    }

    // Convert Base64 to Base64URL by replacing “+” with “-” and “/” with “_”
    $url = strtr($b64, '+/', '-_');

    // Remove padding character from the end of line and return the Base64URL result
    return rtrim($url, '=');
}

/**
 * Decode data from Base64URL
 * @param string $data
 * @param boolean $strict
 * @return boolean|string
 */
function decodeBase64url($data, $strict = false)
{
    // Convert Base64URL to Base64 by replacing “-” with “+” and “_” with “/”
    $b64 = strtr($data, '-_', '+/');

    return base64_decode($b64, $strict);
}




/**
 * Registering Cardinity Gateway as a Payment Gateway in EDD
 *
 * @param   array $gateways     Current EDD payment gateways
 * @return  array               Current EDD payment gateways with Cardinity Gateway
 */
function cardinity_edd_register_gateway($gateways)
{
    $gateways[CARDINITY_GATEWAY_NAME] = array(
        'admin_label' => 'Cardinity Gateway',
        'checkout_label' => __('Credit/Debit Card', 'banking'),
    );
    return $gateways;
}
add_filter('edd_payment_gateways', 'cardinity_edd_register_gateway');

/**
 * Register a subsection for Cardinity Gateway in gateway options tab
 *
 * @param   array $gateway_sections     Current Gateway Tab Subsections
 * @return  array                       Gateway Tab Subsections with Cardinity Gateway
 */
function cardinity_edd_register_gateway_section($gateway_sections)
{
    $gateway_sections[CARDINITY_GATEWAY_NAME] = __('Cardinity Gateway', 'banking');
    return $gateway_sections;
}
add_filter('edd_settings_sections_gateways', 'cardinity_edd_register_gateway_section');

/**
 * Register the Cardinity Gateway settings for Cardinity Gateway subsection
 *
 * @param   array $gateway_settings     Gateway Tab Settings
 * @return  array                       Gateway Tab Settings with Cardinity Gateway settings
 */
function cardinity_edd_add_gateway_settings($gateway_settings)
{
    $cardinity_settings = array(
        array(
            'id' => CARDINITY_GATEWAY_NAME . '_settings',
            'name' => '<strong>' . __('Cardinity Gateway Settings', 'banking') . '</strong>',
            'desc' => __('Configure Cardinity Gateway Settings', 'banking'),
            'type' => 'header',
        ),
        array(
            'id' => CARDINITY_GATEWAY_NAME . '_desc',
            'name' => __('API keys', 'banking'),
            'type' => 'descriptive_text',
            'desc' => __('Enter your Cardinity credentials.
                            You can find them on your Cardinity members area under
                            Integration -> API Settings.', 'banking'),
        ),
        array(
            'id' => CARDINITY_GATEWAY_NAME . '_test_api_key',
            'name' => __('Test API Key', 'banking'),
            'type' => 'text',
            'desc' => __('Enter your test API key', 'banking'),
            'size' => 'regular',
        ),
        array(
            'id' => CARDINITY_GATEWAY_NAME . '_test_api_secret',
            'name' => __('Test API Secret', 'banking'),
            'type' => 'text',
            'desc' => __('Enter your test API secret', 'banking'),
            'size' => 'regular',
        ),
        array(
            'id' => CARDINITY_GATEWAY_NAME . '_live_api_key',
            'name' => __('Live API Key', 'banking'),
            'type' => 'text',
            'desc' => __('Enter your live API key', 'banking'),
            'size' => 'regular',
        ),
        array(
            'id' => CARDINITY_GATEWAY_NAME . '_live_api_secret',
            'name' => __('Live API Secret', 'banking'),
            'type' => 'text',
            'desc' => __('Enter your live API secret', 'banking'),
            'size' => 'regular',
        ),
        array(
            'id' => CARDINITY_GATEWAY_NAME . '_external_enable',
            'name' => __('Enable External', 'banking'),
            'type' => 'checkbox',
            'default' => 'no',
            'desc' => __('Enable to use hosted payment gateway', 'banking'),
            'size' => 'regular',
        ),
        array(
            'id' => CARDINITY_GATEWAY_NAME . '_project_key',
            'name' => __('Cardinity Project ID', 'banking'),
            'type' => 'text',
            'desc' => __('Enter your Project ID', 'banking'),
            'size' => 'regular',
        ),
        array(
            'id' => CARDINITY_GATEWAY_NAME . '_project_secret',
            'name' => __('Cardinity Project Secret', 'banking'),
            'type' => 'text',
            'desc' => __('Enter your Project Secret', 'banking'),
            'size' => 'regular',
        ),
    );
    $cardinity_settings = apply_filters('edd_' . CARDINITY_GATEWAY_NAME . '_settings', $cardinity_settings);
    $gateway_settings[CARDINITY_GATEWAY_NAME] = $cardinity_settings;
    return $gateway_settings;
}
add_filter('edd_settings_gateways', 'cardinity_edd_add_gateway_settings');


/**
 * Add custom data to checkout form
 */
function cardinity_edd_browser_info_fields() {
    echo "
    <input type='hidden' id='screen_width' name='cardinity_screen_width' value='' />                
    <input type='hidden' id='screen_height' name='cardinity_screen_height' value='' />                
    <input type='hidden' id='browser_language' name='cardinity_browser_language' value='' />                
    <input type='hidden' id='challenge_window_size' name='cardinity_challenge_window_size' value='' />
    <input type='hidden' id='color_depth' name='cardinity_color_depth' value='' />                
    <input type='hidden' id='time_zone' name='cardinity_time_zone' value='' />
    ";

    echo '
    <script type="text/javascript">
    document.addEventListener("DOMContentLoaded", function() {

        document.getElementById("screen_width").value = window.innerWidth;
        document.getElementById("screen_height").value = window.innerHeight;
        document.getElementById("browser_language").value = navigator.language;
        document.getElementById("color_depth").value = screen.colorDepth;
        document.getElementById("time_zone").value = new Date().getTimezoneOffset();

        var availChallengeWindowSizes = [
            [600, 400],
            [500, 600],
            [390, 400],
            [250, 400]
        ];

        var cardinity_screen_width = window.innerWidth;
        var cardinity_screen_height = window.innerHeight;
        document.getElementById("challenge_window_size").value = "full-screen";

        //display below 800x600        
        if (!(cardinity_screen_width > 800 && cardinity_screen_height > 600)) {                        
            //find largest acceptable size
            availChallengeWindowSizes.every(function(element, index) {
                console.log(element);
                if (element[0] > cardinity_screen_width || element[1] > cardinity_screen_height) {
                    //this challenge window size is not acceptable                    
                    return true;
                } else {
                    document.getElementById("challenge_window_size").value = element[0]+"x"+element[1];                    
                    return false;
                }        
            });
        }   

    });
    </script>
    ';
}

add_action( 'edd_purchase_form_user_info_fields', 'cardinity_edd_browser_info_fields' );


function cardinity_edd_external_nocc() { 	
   	

	$logged_in = is_user_logged_in();
	$customer  = EDD()->session->get( 'customer' );
	$customer  = wp_parse_args( $customer, array( 'address' => array(
		'line1'   => '',
		'line2'   => '',
		'city'    => '',
		'zip'     => '',
		'state'   => '',
		'country' => ''
	) ) );

	$customer['address'] = array_map( 'sanitize_text_field', $customer['address'] );

	if( $logged_in ) {

		$user_address = get_user_meta( get_current_user_id(), '_edd_user_address', true );

		foreach( $customer['address'] as $key => $field ) {
			if ( empty( $field ) && ! empty( $user_address[ $key ] ) ) {
				$customer['address'][ $key ] = $user_address[ $key ];
			} else {
                $customer['address'][ $key ] = '';
			}
		}

	}

	ob_start(); ?>

	<fieldset id="edd_cc_address" class="cc-address">
		<span><legend><?php _e( 'Billing Details', 'banking' ); ?></legend></span>
		<?php do_action( 'edd_cc_billing_top' ); ?>
		<p id="edd-card-address-wrap">
			<label for="card_address" class="edd-label">
				<?php _e( 'Billing Address', 'banking' ); ?>
				<?php if( edd_field_is_required( 'card_address' ) ) { ?>
					<span class="edd-required-indicator">*</span>
				<?php } ?>
			</label>
			<span class="edd-description"><?php _e( 'The primary billing address for your credit card.', 'banking' ); ?></span>
			<input type="text" id="card_address" name="card_address" class="card-address edd-input<?php if( edd_field_is_required( 'card_address' ) ) { echo ' required'; } ?>" placeholder="<?php _e( 'Address line 1', 'banking' ); ?>" value="<?php echo $customer['address']['line1']; ?>"<?php if( edd_field_is_required( 'card_address' ) ) {  echo ' required '; } ?>/>
		</p>

		<p id="edd-card-address-2-wrap">
			<label for="card_address_2" class="edd-label">
				<?php _e( 'Billing Address Line 2 (optional)', 'banking' ); ?>
				<?php if( edd_field_is_required( 'card_address_2' ) ) { ?>
					<span class="edd-required-indicator">*</span>
				<?php } ?>
			</label>

			<span class="edd-description"><?php _e( 'The suite, apt no, PO box, etc, associated with your billing address.', 'banking' ); ?></span>
			<input type="text" id="card_address_2" name="card_address_2" class="card-address-2 edd-input<?php if( edd_field_is_required( 'card_address_2' ) ) { echo ' required'; } ?>" placeholder="<?php _e( 'Address line 2', 'banking' ); ?>" value="<?php echo $customer['address']['line2']; ?>"<?php if( edd_field_is_required( 'card_address_2' ) ) {  echo ' required '; } ?>/>
		</p>

		<p id="edd-card-city-wrap">
			<label for="card_city" class="edd-label">
				<?php _e( 'Billing City', 'banking' ); ?>
				<?php if( edd_field_is_required( 'card_city' ) ) { ?>
					<span class="edd-required-indicator">*</span>
				<?php } ?>
			</label>

			<span class="edd-description"><?php _e( 'The city for your billing address.', 'banking' ); ?></span>
			<input type="text" id="card_city" name="card_city" class="card-city edd-input<?php if( edd_field_is_required( 'card_city' ) ) { echo ' required'; } ?>" placeholder="<?php _e( 'City', 'banking' ); ?>" value="<?php echo $customer['address']['city']; ?>"<?php if( edd_field_is_required( 'card_city' ) ) {  echo ' required '; } ?>/>
		</p>
		<p id="edd-card-zip-wrap">
			<label for="card_zip" class="edd-label">
				<?php _e( 'Billing Zip / Postal Code', 'banking' ); ?>
				<?php if( edd_field_is_required( 'card_zip' ) ) { ?>
					<span class="edd-required-indicator">*</span>
				<?php } ?>
			</label>
			<span class="edd-description"><?php _e( 'The zip or postal code for your billing address.', 'banking' ); ?></span>
			<input type="text" size="4" name="card_zip" class="card-zip edd-input<?php if( edd_field_is_required( 'card_zip' ) ) { echo ' required'; } ?>" placeholder="<?php _e( 'Zip / Postal Code', 'banking' ); ?>" value="<?php echo $customer['address']['zip']; ?>"<?php if( edd_field_is_required( 'card_zip' ) ) {  echo ' required '; } ?>/>
		</p>

		<p id="edd-card-country-wrap">
			<label for="billing_country" class="edd-label">
				<?php _e( 'Billing Country', 'banking' ); ?>
				<?php if( edd_field_is_required( 'billing_country' ) ) { ?>
					<span class="edd-required-indicator">*</span>
				<?php } ?>
			</label>

			<span class="edd-description"><?php _e( 'The country for your billing address.', 'banking' ); ?></span>
			<select name="billing_country" id="billing_country" class="billing_country edd-select<?php if( edd_field_is_required( 'billing_country' ) ) { echo ' required'; } ?>"<?php if( edd_field_is_required( 'billing_country' ) ) {  echo ' required '; } ?>>
				<?php
				$selected_country = edd_get_shop_country();
				if( ! empty( $customer['address']['country'] ) && '*' !== $customer['address']['country'] ) {
					$selected_country = $customer['address']['country'];
				}

				$countries = edd_get_country_list();
				foreach( $countries as $country_code => $country ) {
				  echo '<option value="' . esc_attr( $country_code ) . '"' . selected( $country_code, $selected_country, false ) . '>' . $country . '</option>';
				}
				?>
			</select>
		</p>
		<p id="edd-card-state-wrap">
			<label for="card_state" class="edd-label">
				<?php _e( 'Billing State / Province', 'banking' ); ?>
				<?php if( edd_field_is_required( 'card_state' ) ) { ?>
					<span class="edd-required-indicator">*</span>
				<?php } ?>
			</label>
			<span class="edd-description"><?php _e( 'The state or province for your billing address.', 'banking' ); ?></span>
			<?php
			$selected_state = edd_get_shop_state();
			$states         = edd_get_shop_states( $selected_country );
			if( ! empty( $customer['address']['state'] ) ) {
				$selected_state = $customer['address']['state'];
			}

			if( ! empty( $states ) ) : ?>
			<select name="card_state" id="card_state" class="card_state edd-select<?php if( edd_field_is_required( 'card_state' ) ) { echo ' required'; } ?>">
				<?php
					foreach( $states as $state_code => $state ) {
						echo '<option value="' . $state_code . '"' . selected( $state_code, $selected_state, false ) . '>' . $state . '</option>';
					}
				?>
			</select>
			<?php else : ?>
			<?php $customer_state = ! empty( $customer['address']['state'] ) ? $customer['address']['state'] : ''; ?>
			<input type="text" size="6" name="card_state" id="card_state" class="card_state edd-input" value="<?php echo esc_attr( $customer_state ); ?>" placeholder="<?php _e( 'State / Province', 'banking' ); ?>"/>
			<?php endif; ?>
		</p>
		<?php do_action( 'edd_cc_billing_bottom' ); ?>	

	</fieldset>	

	<?php	

	echo ob_get_clean();
}

//if external remove cc form, keep billing form
if($is_external_enabled){
    add_action("edd_" . CARDINITY_GATEWAY_NAME."_cc_form", 'cardinity_edd_external_nocc');
}


/**
 * Process purchase through Cardinitity Gateway
 *
 * @param   array $purchase_data    Purchase Data
 * @return  void
 */
function cardinity_edd_process_payment($purchase_data)
{
    
    //Verify nonce
    if (!wp_verify_nonce($purchase_data['gateway_nonce'], 'edd-gateway')) {
        wp_die(__('Nonce verification has failed', 'banking'),
            __('Error', 'banking'), array('response' => 403));
    }

    //check for errors in the form
    $errors = edd_get_errors();
    if (!$errors) {
        $edd_payment_id = array(
            'price' => $purchase_data['price'],
            'date' => $purchase_data['date'],
            'user_email' => $purchase_data['user_email'],
            'purchase_key' => $purchase_data['purchase_key'],
            'currency' => edd_get_currency(),
            'purchase' => $purchase_data['purchase'],
            'cart_details' => $purchase_data['cart_details'],
            'user_info' => $purchase_data['user_info'],
            'status' => 'pending',
        );

        // create a record of the pending payment into EDD payment history
        $edd_payment_id = edd_insert_payment($edd_payment_id);

        //padding order ID in case the length is less than 2
        $cardinity_order_id = strval(edd_get_payment($edd_payment_id)->number);
        $cardinity_order_id = str_pad($cardinity_order_id, 2, '0', STR_PAD_LEFT);

        // Remove whitespace from card number
        $card_number = preg_replace('/\s+/','', $purchase_data['post_data']['card_number']);

        
        $get_params = array("edd-listener" => CARDINITY_GATEWAY_NAME);
        $notificationUrl = edd_get_checkout_uri($get_params);


        $paymentMethodParams = [
            'amount' => $purchase_data['price'],
            'currency' => edd_get_currency(),
            'settle' => true,
            'order_id' => $cardinity_order_id,
            'country' => $purchase_data['post_data']['billing_country'],
            'payment_method' => Cardinity\Method\Payment\Create::CARD,
            'payment_instrument' => [
                'pan' => $card_number,
                'exp_year' => (int) $purchase_data['post_data']['card_exp_year'],
                'exp_month' => (int) $purchase_data['post_data']['card_exp_month'],
                'cvc' => $purchase_data['post_data']['card_cvc'],
                'holder' => $purchase_data['post_data']['card_name'],
            ],
            'threeds2_data' =>  [
                "notification_url" =>  $notificationUrl,   
                "browser_info" => [
                    "accept_header" => "text/html",
                    "browser_language" => $purchase_data['post_data']['cardinity_browser_language'] ?? "en-US",
                    "screen_width" => (int) $purchase_data['post_data']['cardinity_screen_width']  ?? 1920,
                    "screen_height" => (int) $purchase_data['post_data']['cardinity_screen_height']  ?? 1040,
                    'challenge_window_size' => $purchase_data['post_data']['cardinity_challenge_window_size'] ?? 'full-screen',
                    "user_agent" => $_SERVER['HTTP_USER_AGENT'] ?? "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:21.0) Gecko/20100101 Firefox/21.0",
                    "color_depth" => (int) $purchase_data['post_data']['cardinity_color_depth'] ?? 24,
                    "time_zone" =>  (int) $purchase_data['post_data']['cardinity_time_zone']?? -60
                ],
            ]
        ];

        //initialize cardinity payment
        $method = new Cardinity\Method\Payment\Create($paymentMethodParams);

        cardinity_edd_call_payment_api($edd_payment_id, $method);

    }
}


/**
 * Process payment through external gateway
 */
function cardinity_edd_external_payment($purchase_data)
{    
    //Verify nonce
    if (!wp_verify_nonce($purchase_data['gateway_nonce'], 'edd-gateway')) {
        wp_die(__('Nonce verification has failed', 'banking'),
            __('Error', 'banking'), array('response' => 403));
    }

    //check for errors in the form
    $errors = edd_get_errors();
    if (!$errors) {
        $edd_payment_id = array(
            'price' => $purchase_data['price'],
            'date' => $purchase_data['date'],
            'user_email' => $purchase_data['user_email'],
            'purchase_key' => $purchase_data['purchase_key'],
            'currency' => edd_get_currency(),
            'purchase' => $purchase_data['purchase'],
            'cart_details' => $purchase_data['cart_details'],
            'user_info' => $purchase_data['user_info'],
            'status' => 'pending',
        );

        // create a record of the pending payment into EDD payment history
        $edd_payment_id = edd_insert_payment($edd_payment_id);

        //padding order ID in case the length is less than 2
        $cardinity_order_id = strval(edd_get_payment($edd_payment_id)->number);
        $cardinity_order_id = str_pad($cardinity_order_id, 2, '0', STR_PAD_LEFT);

        // Remove whitespace from card number
        $card_number = preg_replace('/\s+/','', $purchase_data['post_data']['card_number']);
        
        $get_params = array(
            "edd-listener" => CARDINITY_GATEWAY_NAME,
            "external-callback" => 'true',
        );
        $cancel_url = edd_get_checkout_uri($get_params);

        $get_params = array(
            "edd-listener" => CARDINITY_GATEWAY_NAME,
            "external-callback" => 'true',
        );
        $callback_url = edd_get_checkout_uri($get_params);

        $amount = number_format((float) $purchase_data['price'], 2, '.', '') ;
        $cancel_url = $cancel_url;
        $country = $purchase_data['post_data']['billing_country'];
        $currency = edd_get_currency();
        $description = $edd_payment_id ; //. '&crd=' . $cardinity_payment->getId();
        $order_id =  $cardinity_order_id;
        $return_url =  $callback_url;

        global $edd_options;        
        $project_id = $edd_options[CARDINITY_GATEWAY_NAME . '_project_key'];
        $project_secret = $edd_options[CARDINITY_GATEWAY_NAME . '_project_secret'];

        $attributes = [
            "amount" => $amount,
            "currency" => $currency,
            "country" => $country,
            "order_id" => $order_id,
            "description" => $description,
            "project_id" => $project_id,
            "cancel_url" => $cancel_url,
            "return_url" => $return_url,
        ];
            
        ksort($attributes);

        $message = '';
        foreach($attributes as $key => $value) {
            $message .= $key.$value;
        }

        $signature = hash_hmac('sha256', $message, $project_secret);

        //Build the external request form
        $requestForm = '<html>
        <head>
            <title>Request Example | Hosted Payment Page</title>
            <script type="text/javascript">setTimeout(function() { document.getElementById("externalPaymentForm").submit(); }, 5000);</script>
        </head>
        <body>
            <div style="text-align: center; width: 300px; position: fixed; top: 30%; left: 50%; margin-top: -50px; margin-left: -150px;">
                <h2>You will be redirected to external gateway shortly. </h2>
                <p>If browser does not redirect after 5 seconds, press Submit</p>
                <form id="externalPaymentForm" name="checkout" method="POST" action="https://checkout.cardinity.com">                    
                    <button type=submit>Click Here</button>
                    <input type="hidden" name="amount" value="' . $attributes['amount'] . '" />
                    <input type="hidden" name="cancel_url" value="' . $attributes['cancel_url'] . '" />
                    <input type="hidden" name="country" value="' . $attributes['country'] . '" />
                    <input type="hidden" name="currency" value="' . $attributes['currency'] . '" />
                    <input type="hidden" name="description" value="' . $attributes['description'] . '" />
                    <input type="hidden" name="order_id" value="' . $attributes['order_id'] . '" />
                    <input type="hidden" name="project_id" value="' . $attributes['project_id'] . '" />
                    <input type="hidden" name="return_url" value="' . $attributes['return_url'] . '" />
                    <input type="hidden" name="signature" value="' . $signature . '" />
                </form>
            </div>
        </body>
        </html>';

        echo $requestForm;
        //we dont want to do anything else. just show html form and redirect
        exit();
    }
}


if($is_external_enabled){
    add_action("edd_gateway_" . CARDINITY_GATEWAY_NAME, 'cardinity_edd_external_payment');
}else{
    add_action("edd_gateway_" . CARDINITY_GATEWAY_NAME, 'cardinity_edd_process_payment');
}


/**
 * Listens for 3D Secure responses and forwards them to the processing function
 *
 * @return void
 */
function cardinity_edd_listen_for_3dsecure()
{
    if (isset($_GET['edd-listener']) && $_GET['edd-listener'] == CARDINITY_GATEWAY_NAME) {
        //this is here for 3ds 
        do_action('cardinity_verify_3dsecure');
    }
}

/**
 * Listens for External responses and forwards them to the processing function
 *
 * @return void
 */
function cardinity_edd_listen_for_external()
{
    if (isset($_GET['edd-listener']) && $_GET['edd-listener'] == CARDINITY_GATEWAY_NAME) {
        if (isset($_GET['external-callback']) && $_GET['external-callback'] == "true") {
            //this is here for External
            do_action('cardinity_finalize_external');
        }
    }
}

if($is_external_enabled){
    add_action('init', 'cardinity_edd_listen_for_external');
}else{
    add_action('init', 'cardinity_edd_listen_for_3dsecure');
}


/**
 * Processes External Response
 *
 * @return void
 */
function cardinity_edd_process_external()
{
    
    //edd payment id is on description
    $edd_payment_id = $_POST['description'];
    $payment_id = $_POST['id'];

    if ($_POST['status'] == 'approved') {

        //complete the order
        edd_update_payment_status($edd_payment_id, 'complete');

        //Stores Cardinity purchase key for further use in refunds
        edd_update_payment_meta($edd_payment_id, 'purchase_key', $payment_id);    
        edd_insert_payment_note($edd_payment_id, __('Cardinity payment approved, ID: ' . $payment_id, 'banking'));

        //finish
        edd_empty_cart();
        edd_send_to_success_page();

    } else { // Should never happen
        edd_set_error('unexpected_error', __('Unexpected error', 'banking'));
        edd_insert_payment_note($edd_payment_id, __('Unexpected Error: Unexpected payment status', 'banking'));
        edd_update_payment_status($edd_payment_id, 'failed');
        edd_send_back_to_checkout('?payment-mode=' . CARDINITY_GATEWAY_NAME);
    }
    
}
add_action('cardinity_finalize_external', 'cardinity_edd_process_external');



/**
 * Processes 3D secure responses
 *
 * @return void
 */
function cardinity_edd_process_3dsecure()
{

      
    if(isset($_POST['MD']) && !isset($_POST['threeDSSessionData'])){
        //its version 1
        $params = explode('&crd=', $_POST['MD']);
        $edd_payment_id = $params[0];
        $method = new Cardinity\Method\Payment\Finalize($params[1], $_POST['PaRes']);
        
    }else{
        //its version 2
        $params = explode('&crd=', decodeBase64url($_POST['threeDSSessionData']));
        $edd_payment_id = $params[0];
        $method = new Cardinity\Method\Payment\Finalize($params[1], $_POST['cres'], true);

        //cardinity_edd_call_payment_api($edd_payment_id, $method);
    }

    cardinity_edd_call_payment_api($edd_payment_id, $method);
    
}
add_action('cardinity_verify_3dsecure', 'cardinity_edd_process_3dsecure');



function prepareThreeDSecureV2Form($acs_url, $creq, $threeDSSessionData){
    return <<<EOD
        <p>
            Redirecting to 3D-Secure Version 2 Authorization page.
            If your browser does not start loading the page,
            press the button below.
            You will be sent back to this site after you
            authorize the transaction.
        </p>
        <form name="ThreeDForm" id="ThreeDForm" method="POST" action="$acs_url">
            <button type=submit>Click Here</button>
            <input type="hidden" name="creq" value="$creq" />
            <input type="hidden" name="threeDSSessionData" value="$threeDSSessionData" />
        </form>
        <script>
        window.onload=function(){ 
            window.setTimeout(document.ThreeDForm.submit.bind(document.ThreeDForm), 2000);
        };
        </script>
    EOD;
}
function prepareThreeDSecureForm($acsUrl, $paReq, $termUrl, $md) {
    return <<<EOD
    <p>
        Redirecting to 3D-Secure  Version 1 Authorization page.
        If your browser does not start loading the page,
        press the button below.
        You will be sent back to this site after you
        authorize the transaction.
    </p>
    <form name="ThreeDForm" id="ThreeDForm" method="POST" action="$acsUrl">
        <button type=submit>Click Here</button>
        <input type="hidden" name="PaReq" value="$paReq" />
        <input type="hidden" name="TermUrl" value="$termUrl" />
        <input type="hidden" name="MD" value="$md" />
    </form>
    <script>
    window.onload=function(){ 
        window.setTimeout(document.ThreeDForm.submit.bind(document.ThreeDForm), 2000);
    };
    </script>
EOD;
}


/**
 * Processes cardinity payment requests
 *
 * @param   int $edd_payment_id     EDD payment ID
 * @param   object $method          Cardinity API method
 * @return  void
 */
function cardinity_edd_call_payment_api($edd_payment_id, $method)
{
    try {
        $client = cardinity_edd_get_client();
        $cardinity_payment = $client->call($method);

        $payment_status = $cardinity_payment->getStatus();

        if ($payment_status == 'approved') {
            edd_update_payment_status($edd_payment_id, 'complete');
            $payment_id = $cardinity_payment->getId();

            //Stores Cardinity purchase key for further use in refunds
            edd_update_payment_meta($edd_payment_id, 'purchase_key', $payment_id);

            edd_insert_payment_note($edd_payment_id, __('Cardinity payment approved, ID: ' . $payment_id, 'banking'));
            edd_empty_cart();
            edd_send_to_success_page();
        } else if ($payment_status == 'pending') {             
            //Required 3D Secure authorization


            //Is v2
            if( $cardinity_payment->isThreedsV2() && ! $cardinity_payment->isThreedsV1()){

                $acs_url = $cardinity_payment->getThreeds2data()->getAcsUrl();
                $creq = $cardinity_payment->getThreeds2data()->getCReq();
                $threeDSSessionData = $edd_payment_id . '&crd=' . $cardinity_payment->getId();

                // Append Cardinity Gateway URL parameter for 3D-secure callback
                //$get_params = array("edd-listener" => CARDINITY_GATEWAY_NAME);
                //$termUrl = edd_get_checkout_uri($get_params);
                //Insert both payment EDD payment ID and Cardinity payment ID, separated by '&crd=' for later parsing
                //EDD payment for changing status in the system, Cardinity ID for payment finalizing
                //$md = $edd_payment_id . '&crd=' . $cardinity_payment->getId();
    
                //Proceed to 3D secure verification
                print_r(prepareThreeDSecureV2Form($acs_url, $creq, encodeBase64Url($threeDSSessionData)));
                exit();

            }else{

                $url = $cardinity_payment->getAuthorizationInformation()->getUrl();
                $paReq = $cardinity_payment->getAuthorizationInformation()->getData();
                // Append Cardinity Gateway URL parameter for 3D-secure callback
                $get_params = array("edd-listener" => CARDINITY_GATEWAY_NAME);
                $termUrl = edd_get_checkout_uri($get_params);
                //Insert both payment EDD payment ID and Cardinity payment ID, separated by '&crd=' for later parsing
                //EDD payment for changing status in the system, Cardinity ID for payment finalizing
                $md = $edd_payment_id . '&crd=' . $cardinity_payment->getId();
    
                //Proceed to 3D secure verification
                print_r(prepareThreeDSecureForm($url, $paReq, $termUrl, $md));
                exit();
            }



          
        } else { // Should never happen
            edd_set_error('unexpected_error', __('Unexpected error', 'banking'));
            edd_insert_payment_note($edd_payment_id, __('Unexpected Error: Unexpected payment status', 'banking'));
            $fail = true;
        }

    } catch (Cardinity\Exception\InvalidAttributeValue $exception) {
        $violations = $exception->getViolations();
        foreach ($violations as $violation) {
            edd_set_error('validation_error', __('Invalid Value. ' . $violation->getMessage(), 'banking'));
            edd_insert_payment_note($edd_payment_id, __('Payment Failed: ' . $violation->getMessage(), 'banking'));
        }
        $fail = true;
    } catch (Cardinity\Exception\Unauthorized $exception) {
        edd_set_error('unauthorized_error', __('Authorization error. Check API key settings.', 'banking'));
        edd_insert_payment_note($edd_payment_id, __('Payment Failed: Authorization error. Check API key settings.', 'banking'));
        $fail = true;
    } catch (Cardinity\Exception\Request $exception) {
        $errors = $exception->getErrors();
        $errorString = '';
        foreach ($errors as $error) {
            $errorString .= $error['message'] .= ' ';
        }
        edd_set_error('request_error', __('Payment Failed. ' . $errorString, 'banking'));
        edd_insert_payment_note($edd_payment_id, __('Payment Failed: ' . $errorString, 'banking'));
        $fail = true;
    } catch (Cardinity\Exception\Runtime $exception) {
        edd_set_error('runtime_error', __('Payment Failed. Internal Error.', 'banking'));
        edd_insert_payment_note($edd_payment_id, __('Payment Failed: ' . $exception->getMessage(), 'banking'));
        $fail = true;
    }

    //Payment Error Handling
    if ($fail) {
        edd_update_payment_status($edd_payment_id, 'failed');
        edd_send_back_to_checkout('?payment-mode=' . CARDINITY_GATEWAY_NAME);
    }
}


function cardinity_edd_call_refund_api($payment)
{
    try {
        $client = cardinity_edd_get_client();

        $method = new Cardinity\Method\Refund\Create(
            $payment->get_meta('purchase_key'),
            floatval($payment->total)
        );

        $cardinity_refund = $client->call($method);

        if ($cardinity_refund->getStatus() == 'approved') {
            $payment->add_note(__('Refund successful. Refund ID: ' . $cardinity_refund->getId(), 'banking'));
        } else { //Should never happen
            $payment->add_note(__('Unexpected Refund Error', 'banking'));
        }
    } catch (Cardinity\Exception\Request $exception) {
        $errorString = '';
        foreach ($exception->getErrors() as $error) {
            $errorString .= $error['message'] .= ' ';
        }
        $payment->add_note(__('Refund declined: ' . $errorString, 'banking'));
    } catch (Cardinity\Exception\Runtime $exception) {
        $payment->add_note(__('Refund declined: ' . $exception->getMessage(), 'banking'));
    }
}
add_action('edd_pre_refund_payment', 'cardinity_edd_call_refund_api');

function cardinity_edd_get_client()
{
    global $edd_options;
    if (edd_is_test_mode()) {
        $key = $edd_options[CARDINITY_GATEWAY_NAME . '_test_api_key'];
        $secret = $edd_options[CARDINITY_GATEWAY_NAME . '_test_api_secret'];
    } else {
        $key = $edd_options[CARDINITY_GATEWAY_NAME . '_live_api_key'];
        $secret = $edd_options[CARDINITY_GATEWAY_NAME . '_live_api_secret'];
    }

    //initiate cardinity client
    $client = Cardinity\Client::create([
        'consumerKey' => $key,
        'consumerSecret' => $secret,
    ]);
    return $client;
}
